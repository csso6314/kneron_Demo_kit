# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************
from .KPBaseClass.LibLoaderBase import LibLoaderBase


class KPLibLoader(LibLoaderBase):
    def __init__(self):
        super(KPLibLoader, self).__init__(package_name='kp')

    def _init_kneron_libs(self):
        self._kneron_libs = [
            'libkplus.{}'.format(LibLoaderBase.EXTENSION_FLAG)
        ]

    def _init_share_libs_load_order(self):
        if 'Windows' == self._platform_system:
            self._share_libs_load_order = [
                'libwinpthread-1.{}'.format(LibLoaderBase.EXTENSION_FLAG),
                'libgcc_s_seh-1.{}'.format(LibLoaderBase.EXTENSION_FLAG),
                'libstdc++-6.{}'.format(LibLoaderBase.EXTENSION_FLAG),
                'libusb-1.0.{}'.format(LibLoaderBase.EXTENSION_FLAG),
                'libwdi.{}'.format(LibLoaderBase.EXTENSION_FLAG),
                'libkplus.{}'.format(LibLoaderBase.EXTENSION_FLAG),
            ]
        elif 'Darwin' == self._platform_system:
            self._share_libs_load_order = [
                'libusb-1.0.0.{}'.format(LibLoaderBase.EXTENSION_FLAG),
                'libkplus.{}'.format(LibLoaderBase.EXTENSION_FLAG)
            ]
        else:
            self._share_libs_load_order = [
                'libusb-1.0.{}.0'.format(LibLoaderBase.EXTENSION_FLAG),
                'libkplus.{}'.format(LibLoaderBase.EXTENSION_FLAG)
            ]
