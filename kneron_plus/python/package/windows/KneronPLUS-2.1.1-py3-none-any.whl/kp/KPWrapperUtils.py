# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************

from .KPWrapper import KPWrapper
from .KPStructure import ModelNefDescriptorBuffer
import ctypes


class KPWrapperUtils:
    __KP_WRAPPER = KPWrapper()

    @staticmethod
    def c_free(pointer: int):
        KPWrapperUtils.__KP_WRAPPER.LIB.py_c_free(ctypes.byref(pointer))

    @staticmethod
    def disconnect_devices_by_address(device_group_address: int) -> int:
        return KPWrapperUtils.__KP_WRAPPER.LIB.kp_disconnect_devices(device_group_address)

    @staticmethod
    def release_model_nef_descriptor(model_nef_descriptor: ModelNefDescriptorBuffer) -> int:
        return KPWrapperUtils.__KP_WRAPPER.LIB.kp_release_model_nef_descriptor(ctypes.byref(model_nef_descriptor))
