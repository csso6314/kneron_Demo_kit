# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************

from typing import Any
import ctypes
import abc


class BufferBase(ctypes.Structure):
    _pack_ = 4

    def __init__(self, *args: Any, **kw: Any):
        """ check if allocated memory from c """
        super().__init__(*args, **kw)
        self._is_buffer_init = False

        if args or kw:
            self._init_buffer(*args, **kw)
            self._is_buffer_init = True

    @abc.abstractmethod
    def _init_buffer(self, *args: Any, **kw: Any) -> None:
        """ init from python """
        pass

    def is_buffer_init(self) -> bool:
        return self._is_buffer_init
