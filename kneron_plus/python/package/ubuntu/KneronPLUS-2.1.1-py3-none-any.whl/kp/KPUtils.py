# ******************************************************************************
#  Copyright (c) 2021-2022. Kneron Inc. All rights reserved.                   *
# ******************************************************************************

# Legacy Module
from .Legacy.V1.KPValue import \
    GenericRawImageHeader, \
    GenericRawBypassPreProcImageHeader

# Core Module
from .KPValue import \
    DeviceGroup, \
    ModelNefDescriptor
from typing import Union


def _get_model_raw_out_size(generic_inference_data_header: Union[GenericRawImageHeader,
                                                                 GenericRawBypassPreProcImageHeader],
                            model_nef_descriptor: ModelNefDescriptor) -> int:
    max_raw_out_size = -1
    for single_model_descriptor in model_nef_descriptor.models:
        if generic_inference_data_header.model_id == single_model_descriptor.id:
            max_raw_out_size = single_model_descriptor.max_raw_out_size
    return max_raw_out_size


def _get_model_max_raw_out_size(device_group: DeviceGroup) -> int:
    max_raw_out_size = -1
    for single_model_descriptor in device_group.content.loaded_model_nef_descriptor.models:
        if single_model_descriptor.max_raw_out_size > max_raw_out_size:
            max_raw_out_size = single_model_descriptor.max_raw_out_size
    return max_raw_out_size
